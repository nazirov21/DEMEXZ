# [Видео](https://drive.google.com/file/d/1yvycE8qx_LfcSRf4AFvnwSOkcvS_lPum/view?usp=sharing)

![image](https://github.com/user-attachments/assets/f2133bb6-1e4b-4777-ac48-e5b520485805)



![ER](https://github.com/user-attachments/assets/759cc687-f4c6-4447-a13a-c785e2848c09)
